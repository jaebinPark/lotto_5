# 로또 Lab Pro (Full 1.102)
- QR 인식(BarcodeDetector) 포함
